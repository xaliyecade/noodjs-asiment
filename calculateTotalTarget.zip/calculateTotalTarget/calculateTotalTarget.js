
// Function to calculate the total target distribution across months, excluding specific days like Fridays
function calculateTotalTarget(startDate, endDate, totalAnnualTarget, excludeDay = 5) {
  // Helper function to check if a date is a valid working day (excludes the specified day of the week)
  const isValidWorkingDay = (date, excludeDay) => {
    return date.getDay() !== excludeDay;
  };

  // Helper function to get the number of days in a given month and year
  const getDaysInMonth = (year, month) => {
    return new Date(year, month + 1, 0).getDate();
  };

  // Helper function to get all the dates between startDate and endDate
  const getDatesInRange = (start, end) => {
    const dates = [];
    const currentDate = new Date(start);
    end = new Date(end);

    while (currentDate <= end) {
      dates.push(new Date(currentDate));
      currentDate.setDate(currentDate.getDate() + 1);
    }

    return dates;
  };

  const start = new Date(startDate);
  const end = new Date(endDate);

  // Initialize arrays to store the results
  const daysExcludingFridays = [];
  const daysWorkedExcludingFridays = [];
  const monthlyTargets = [];

  let totalWorkingDays = 0;
  let monthlyWorkingDays = {};

  // Get all dates in the given range
  const allDates = getDatesInRange(start, end);

  // Loop through all dates to categorize them by month and exclude Fridays (or the specified day)
  allDates.forEach(date => {
    const year = date.getFullYear();
    const month = date.getMonth();

    // Ensure the month and year combination exists in our dictionary
    if (!monthlyWorkingDays[`${year}-${month}`]) {
      monthlyWorkingDays[`${year}-${month}`] = { totalDays: 0, workedDays: 0 };
    }

    // If the day is a valid working day (not a Friday or other excluded day)
    if (isValidWorkingDay(date, excludeDay)) {
      // Increment total days in this month
      monthlyWorkingDays[`${year}-${month}`].totalDays++;

      // Increment worked days if the date falls within the start and end range
      if (date >= start && date <= end) {
        monthlyWorkingDays[`${year}-${month}`].workedDays++;
        totalWorkingDays++;
      }
    }
  });

  // Calculate proportional distribution of targets
  Object.keys(monthlyWorkingDays).forEach(monthKey => {
    const { totalDays, workedDays } = monthlyWorkingDays[monthKey];

    daysExcludingFridays.push(totalDays);
    daysWorkedExcludingFridays.push(workedDays);

    // Calculate the monthly target proportional to the working days
    const monthlyTarget = (workedDays / totalWorkingDays) * totalAnnualTarget;
    monthlyTargets.push(monthlyTarget);
  });

  // Calculate the total target assigned to the entire date range
  const totalTarget = monthlyTargets.reduce((acc, curr) => acc + curr, 0);

  return {
    daysExcludingFridays,
    daysWorkedExcludingFridays,
    monthlyTargets,
    totalTarget
  };
}

// Example usage
const result = calculateTotalTarget('2024-01-01', '2024-03-31', 5220);
console.log(result);
